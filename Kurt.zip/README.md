# TrafficSimulator
A University project designed to simulate traffic congestion, and possible ways to resolve it.

Please use this program at your own risk.
