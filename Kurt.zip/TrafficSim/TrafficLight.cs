﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrafficSim
{
    class TrafficLight : Sign 
    {
        int Delay;

        public override string RoadRestriction()
        {

        }
    }
}
