﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using TrafficSim.Entity;

namespace UnitTests
{
    [TestClass]
    public class DriverTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
